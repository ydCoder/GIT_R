//定义修改时数据变量
var editValue00;
//操作对象
var this_a; 
//当前页数
var this_page; 
//每页条数
var page_size; 
//分页最后一页剩下条数
var yushu_page; 
//分页总页数
var count_page; 
var order_by;
//延时
function sleep(d){
    for(var t = Date.now();Date.now() - t <= d;);
}

//数据操作ajxa方法
function DB_ajax(table_key, data_value, data_type, data_file, toUrl, reUrl)
{
    $("#loading").css({
        "display": "block", 
        "z-index": "999"
    }); 
    $.ajax({
        async: true,
        cache: false,
        timeout: 10000,
        url: toUrl+"?"+Math.random(),
        type: "post",
        data: {
            "table_key": table_key,
            "data_type": data_type,
            "data_value": data_value,
            "data_file": data_file
        },
        error: function (jqXHR, textStatus, errorThrown) {
            layer.closeAll('loading');
            layer.alert('操作失败!<br/>请检查网络是否正常！', {
                icon: 5,
                title:'操作提示：',
                yes: function(index){
                    layer.close(index);      
                    if(data_type=="update"){
                        this_a.val(editValue00);
                        this_a.focus();
                    }
                }
            });
        },
        success: function (data) {
            //alert(data);
            data = $.trim(data);
            if (data == "true") {
                if (data_type!="update") {
                    if (reUrl == "") {
                        //location.reload(true);
                        if(data_type=="add"){
                            if(order_by.indexOf("desc")>-1){
                                submit0(1);
                            }else{
                                if(yushu_page==0){
                                    submit0(parseInt(count_page)+1);
                                } else {
                                    submit0(count_page);
                                }
                            }
                        } else  if(data_type=="delete"&&(yushu_page==1||page_size==1)&&this_page==count_page){
                            submit0(parseInt(this_page)-1);
                        }
                        else{
                            submit0(this_page);
                        }
                    } else {
                        window.location.href = reUrl;
                    }
                }else{
                    this_a.css('color','#222222');
                }
            } else if (data == "false") {
                layer.alert("添加失败", {
                    icon: 5,
                    title:'操作提示：',
                    yes: function(index){
                        layer.close(index);      
                        if(data_type=="update"){
                            this_a.val(editValue00);
                            this_a.focus();
                        }
                    }
                });
            }else  {
                layer.alert(data, {
                    icon: 5,
                    title:'操作提示：',
                    yes: function(index){
                        layer.close(index);      
                        if(data_type=="update"){
                            this_a.val(editValue00);
                            this_a.focus();
                        }
                    }
                });
            }
        }
    });
    $("#loading").css({
        "display": "none", 
        "z-index": "999"
    });
}

//数据操作
function DB_control(table_key,data_value,data_type, data_file, toUrl, reUrl,info)
{ 
    // sleep(5000);
    if(info!=""){
        layer.confirm(info,
        {
            btn: ["确定", "取消"],
            icon: 3
        },
        function () {
            DB_ajax(table_key, data_value, data_type, data_file, toUrl, reUrl);
        })
    }else{
        DB_ajax(table_key, data_value, data_type, data_file, toUrl, reUrl);
    }
}


//按钮数据操作reset等
function DB_control_btn(table_key,data_value,data_type, data_file, toUrl, reUrl,info)
{ 
    // sleep(5000);
    if(info!=""){
        layer.confirm(info,
        {
            btn: ["确定", "取消"],
            icon: 3
        },
        function () {
            DB_ajax_btn(table_key, data_value, data_type, data_file, toUrl, reUrl);
        })
    }else{
        DB_ajax_btn(table_key, data_value, data_type, data_file, toUrl, reUrl);
    }
}


function DB_ajax_btn(table_key, data_value, data_type, data_file, toUrl, reUrl)
{
    $.ajax({
        async: true,
        cache: false,
        timeout: 10000,
        url: "db_control.jsp?"+Math.random(),
        type: "post",
        data: {
            "table_key": table_key,
            "data_type":  data_type,
            "data_value": data_value,
            "data_file": data_file
        },
        error: function (jqXHR, textStatus, errorThrown) {
            layer.closeAll('loading');
            layer.alert('操作失败!<br/>请检查网络是否正常！', {
                icon: 5,
                title:'操作提示：',
                yes: function(index){
                    layer.close(index);      
                }
            });
        },
        success: function (data) {
            //alert(data);
            data = $.trim(data);
            if (data == "true") {
                submit0(this_page);
            } else if (data == "false") {
                layer.alert("操作失败", {
                    icon: 5,
                    title:'操作提示：',
                    yes: function(index){
                        layer.close(index);      
                    }
                });
            }
        }
    });
}
//获取修改前数值
$(".edit").focus(
    function() {  
        $(this).css('color','blue');
        editValue0= $(this).val();
    });
//提交查询
function submit0 (a) { 
    $("#page0").val(a);
    $("#submit00").click();
}   
//上移排序
function up_control(table_key,id1,xuhao1,id2,xuhao2,toUrl,reUrl){
    $.ajax({   
        async:true,   
        cache:false,   
        timeout:10000,   
        type:"POST",   
        url:toUrl,   
        data:{
            table_key:table_key,
            id1:id1,
            xuhao1:xuhao1,
            id2:id2,
            xuhao2:xuhao2
        },   
        error:function(jqXHR, textStatus, errorThrown){   
            layer.closeAll('loading');
            layer.alert('操作失败，请检查网络是否正常！', {
                icon: 6
            });
        },   
        success:function(msg){   
            if(msg.indexOf("成功")>-1){
                //                location.reload(true);
                submit0(this_page);
            }else{        
                layer.alert(msg, {
                    icon: 6
                });
            }
        }  
    });   
}
$(".int").blur(
    function() {  
        n=$(this).val().replace(/[ ]/g,"");
        $(this).val(n); 
        if(n!=""){
            this_a=$(this);
            reg = /^\d+$/;
            if(!reg.test(n)||n<1) {
                layer.alert("该数据只能输入大于0的整数！", {
                    icon: 5,
                    title:'操作提示：',
                    yes: function(index){
                        layer.close(index);      
                        this_a.val("");
                        this_a.focus();
                    }
                });
            }
        }
    });
$(".float").blur(
    function() {  
        n=$(this).val().replace(/[ ]/g,"");
        this_a=$(this);
        this_a.val(n); 
        reg = /^\d+(?=\.{0,1}\d+$|$)///验证是正数
        if(!reg.test(n)&&n!="") {
            layer.alert("该数据只能输入不小于0 的正数！", {
                icon: 5,
                title:'操作提示：',
                yes: function(index){
                    layer.close(index);      
                    this_a.val("");
                    this_a.focus();
                }
            });
        }
    });