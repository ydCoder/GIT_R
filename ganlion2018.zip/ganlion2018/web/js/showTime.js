//动态显示日期时间，显示区域ID="show_datetime"：<span id="show_datetime">这里将会动态显示时间</span>
var hours;
var minutes;
var seconds;
function showTime()
{
    var date=new Date();
    var show_day=new Array('星期日','星期一','星期二','星期三','星期四','星期五','星期六'); 
    hours=date.getHours();
    minutes=date.getMinutes();
    seconds=date.getSeconds();
    if(hours<=9)
        hours="0"+hours; 
    if(minutes<=9)
        minutes="0"+minutes;
    if(seconds<=9)
        seconds="0"+seconds;
    var time=date.getFullYear()+"年"
    +(date.getMonth()+1)+"月"
    +date.getDate()+"日 "
    +show_day[date.getDay()]+" "
    +hours+":"
    +minutes+":"
    +seconds;
    $("#show_datetime").html(time);
    setTimeout("showTime()",1000);
}
showTime();