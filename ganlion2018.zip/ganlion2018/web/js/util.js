/*
** randomWord 产生任意长度随机字母数字组合
** randomFlag-是否任意长度 min-任意长度最小位[固定位数] max-任意长度最大位
** xuanfeng 2014-08-28
*/
//new Date().getTime()；获取时间戳
//生成3-32位随机串：randomWord(true, 3, 32)//true可变长度
//生成43位随机串：randomWord(false, 43)//false固定长度
var str = "";
function randomWord(randomFlag, min,str_num, max){
    var str = "";
    range = min;
    if(str_num==1){
        arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    }else if(str_num==2){
        arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    }else{
        arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    }
    // 随机产生
    if(randomFlag){
        range = Math.round(Math.random() * (max-min)) + min;
    }
    for(var i=0; i<range; i++){
        pos = Math.round(Math.random() * (arr.length-1));
        str += arr[pos];
    }
    return str;
}

function table_key(){//自动生成table_key40位随机数+时间戳
    var str =randomWord(false, 40,1)+new Date().getTime();
    return str;
}

function get5_randomWord(){//自动生成6位随机数
    var str =randomWord(false, 6,3);
    return str;
}
function get_employee_chushi_value(){//自动生成用户初始chushi_psw;password;gonghao;em_team_id;em_team_name
    var em_team_id =$("#f_table_id").val();
    var em_team_name =$("#f_table_name").val();
    var gonghao="";
    if(em_team_id!=""){
        $.ajax({
            async: false,
            cache: false,
            timeout: 10000,
            url:"../employee/deal/auto_gonghao.jsp",
            type: "post",
            data: {
                // em_team_id:em_team_id,
                em_team_name:em_team_name
            },
            error: function (jqXHR, textStatus, errorThrown) {
                layer.closeAll('dialog');
                layer.alert('操作失败，请检查网络是否正常！', {
                    icon: 5
                });
            },
            success: function (data) {
                if(data!="1"){
                    gonghao=data.replace(/[ ]/g,"").replace(/[\r\n]/g, ""); 
                }
            }
        })
    }
    var str =randomWord(false, 6,3);
    str="'"+str+"','"+md5(str)+"',"+gonghao+","+em_team_id+",'"+em_team_name+"'";
    return str;
}
//重置用户密码
$(".reset_psw").click(function () {
    var id= $(this).attr("thisid");
    var table_key= $("#table_key").val();
    var str =randomWord(false, 6,3);
    var value =  "chushi_psw='"+str+"',password='" +md5(str)+ "'-&-" + id;
    DB_control_btn(table_key,value, "update","", "db_control.jsp", "","您确认要重置该员工密码么？");  
})
//用户离职
$(".lizhi").click(function () {
    var id= $(this).attr("thisid");
    var table_key= $("#table_key").val();
    var value =  "situation=2-&-" + id;
    DB_control_btn(table_key,value, "update","", "db_control.jsp", "","您确认要操作该员工离职么？");  
})
//解除微信绑定
$(".jiechu_openid").click(function () {
    var id= $(this).attr("thisid");
    var table_key= $("#table_key").val();
    var value =  "openid=''-&-" + id;
    DB_control_btn(table_key,value, "update","", "db_control.jsp", "","您确认要解除该员工Openid么？");  
})


function get_keywords(){//自动生成table_key40位随机数+时间戳
    var str =$("#keywords").val();
    if(str==""){
        str="0";
    }
    return str;
}

function get_f_table_id(){
    var str =$("#f_table_id").val();
    if(str==""){
        str="0";
    }
    return str;
}