/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
    layui.use('layer', function(){ //独立版的layer无需执行这一句
    var $ = layui.jquery, 
    layer = layui.layer; //独立版的layer无需执行这一句
 
})
        
