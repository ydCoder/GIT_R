package util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

public class BirthdayListener implements ServletContextListener {

    public BirthdayListener() {
    }

    public void contextInitialized(ServletContextEvent sce) {
        //System.out.println("服务器已经启动");
        //当web应用启动，开启任务调度---功能在用户的生日当天发送邮件
        //开启一个定时器
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                /**
                 * 要执行的定时操作写在这里
                 */
                //1.获得今天的日期
                SimpleDateFormat format = new SimpleDateFormat("MM-dd hh:mm:ss");
                String currentDate = format.format(new Date());
                System.out.println("定时启动了111");

            }
        }, new Date(), 10000);
        /*24*60*60*1000*/
        //实际开发中起始的时间是个固定时间
        //实际开发中间隔时间是1天   因为客户有很多
    }

    public void contextDestroyed(ServletContextEvent sce) {
        //服务器关闭的时候啊
    }
}
